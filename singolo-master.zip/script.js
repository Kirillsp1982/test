const MENU = document.getElementById('menu');
const GALARY = document.getElementById('galary');
const TAB = document.getElementById('portfolio__buttons');

MENU.addEventListener('click', (event) => {
	MENU.querySelectorAll('li a').forEach(el => el.classList.remove('menu--active'));
	event.target.classList.add('menu--active');
})

GALARY.addEventListener('click', (event) => {
	GALARY.querySelectorAll('img').forEach(el => el.classList.remove('galary--active'));
	event.target.classList.add('galary--active');
})

TAB.addEventListener('click', (event) => {
	TAB.querySelectorAll('botton').forEach(el => el.classList.remove('menu--active'));
	event.target.classList.add('menu--active');
})